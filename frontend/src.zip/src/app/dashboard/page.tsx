import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import { 
  FileText, 
  Users, 
  Plus, 
  ArrowRight, 
  ClipboardCheck, 
  Calendar,
  Monitor
} from "lucide-react";

// 🔴 CAMBIA 'localhost' por tu IP REAL para que funcione en el celular
// Ejemplo: const API_URL = "http://192.168.1.15:3000";
const API_URL = "http://localhost:3000"; 

export default async function DashboardPage() {
  const { userId, getToken } = await auth();
  const user = await currentUser();

  if (!userId || !user) redirect("/");

  const token = await getToken();
  const nombreCompleto = `${user.firstName || ''} ${user.lastName || ''}`.trim() || 'Usuario';
  const email = user.emailAddresses[0]?.emailAddress || '';

  // 1. INICIALIZACIÓN CRÍTICA: Aseguramos que los objetos existan desde el inicio
  let dashboardData = {
    stats: { reports: 0, clients: 0, machines: 0 },
    latestReports: []
  };
  
  try {
    // Sincronizar usuario
    await fetch(`${API_URL}/sync-user`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ clerkId: userId, email, fullName: nombreCompleto }),
    });

    // Pedir estadísticas
    const resStats = await fetch(`${API_URL}/get-stats?clerkId=${userId}`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store"
    });

    if (resStats.ok) {
      const data = await resStats.json();
      // Solo actualizamos si 'data' y 'data.stats' existen realmente
      if (data && data.stats) {
        dashboardData.stats = {
          reports: data.stats.reports || 0,
          clients: data.stats.clients || 0,
          machines: data.stats.machines || 0
        };
      }
      if (data && data.latestReports) {
        dashboardData.latestReports = data.latestReports;
      }
    }
  } catch (error) {
    console.error("⚠️ Error de conexión con el Backend:", error);
    // Si falla, dashboardData se queda con los valores de inicialización (ceros)
  }

  // Desestructuramos con seguridad
  const { stats, latestReports } = dashboardData;

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col gap-2">
        <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight">
          ¡Hola, {user.firstName}! 👋
        </h2>
        <p className="text-slate-500 font-medium">Bienvenido a <span className="text-blue-600 font-bold">Solución Gym</span></p>
      </div>

      {/* 📊 TARJETAS DE MÉTRICAS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard 
          title="Total Reportes" 
          value={stats.reports} 
          icon={<FileText className="text-blue-600" />} 
          bgColor="bg-blue-50" 
        />
        <StatCard 
          title="Clientes" 
          value={stats.clients} 
          icon={<Users className="text-emerald-600" />} 
          bgColor="bg-emerald-50" 
        />
        <StatCard 
          title="Equipos" 
          value={stats.machines} 
          icon={<Monitor className="text-amber-600" />} 
          bgColor="bg-amber-50" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* ACCIONES RÁPIDAS */}
        <div className="lg:col-span-1 space-y-6">
          <h3 className="font-bold text-slate-800 px-1">Acciones Rápidas</h3>
          
          <Link href="/dashboard/mantenimiento" className="group block p-6 bg-slate-900 rounded-3xl shadow-xl hover:bg-blue-600 transition-all duration-300">
            <div className="flex justify-between items-start mb-4">
              <div className="bg-white/10 p-3 rounded-2xl text-white group-hover:bg-white/20">
                <Plus size={24} />
              </div>
              <ArrowRight className="text-slate-500 group-hover:text-white transition-colors" />
            </div>
            <h4 className="text-white font-bold text-lg">Nuevo Reporte</h4>
            <p className="text-slate-400 text-sm mt-1 group-hover:text-blue-50">Crea un informe técnico ahora.</p>
          </Link>

          <div className="p-6 bg-white border border-slate-200 rounded-3xl shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-xl font-black text-blue-600 uppercase shadow-inner">
                {user.firstName?.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-slate-900 truncate">{nombreCompleto}</p>
                <p className="text-[10px] text-slate-400 font-mono truncate">{email}</p>
              </div>
            </div>
          </div>
        </div>

        {/* ÚLTIMA ACTIVIDAD */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center px-1">
            <h3 className="font-bold text-slate-800">Mantenimientos Recientes</h3>
            <Link href="/dashboard/mantenimiento" className="text-blue-600 text-xs font-bold hover:underline uppercase tracking-tighter">
              Ver todo
            </Link>
          </div>

          <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
            {latestReports.length === 0 ? (
              <div className="p-16 text-center">
                <ClipboardCheck size={32} className="mx-auto mb-4 text-slate-300" />
                <p className="text-slate-400 font-bold italic">No hay reportes recientes</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {latestReports.map((report: any) => (
                  <div key={report.id} className="p-5 flex items-center gap-4 hover:bg-slate-50 transition-colors group">
                    <div className="bg-blue-50 p-3 rounded-xl text-blue-600 shadow-inner">
                      <ClipboardCheck size={20} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-slate-800 truncate group-hover:text-blue-600 transition-colors">
                        {report.client?.name || 'Cliente Desconocido'}
                      </p>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1 font-bold uppercase tracking-wider">
                        <Calendar size={12} className="text-blue-400" /> 
                        {new Date(report.date).toLocaleDateString()}
                        <span className="text-slate-200">|</span>
                        <span>Nº {report.reportNumber}</span>
                      </div>
                    </div>
                    <ArrowRight size={18} className="text-slate-200 group-hover:text-blue-500 transition-all" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Sub-componente StatCard
function StatCard({ title, value, icon, bgColor }: { title: string, value: number, icon: React.ReactNode, bgColor: string }) {
  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-6 transition-all hover:shadow-md group">
      <div className={`${bgColor} p-4 rounded-2xl shadow-inner group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.15em] mb-1">{title}</p>
        <p className="text-3xl font-black text-slate-800 tracking-tighter">{value}</p>
      </div>
    </div>
  );
}